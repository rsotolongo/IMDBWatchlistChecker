describe("jsdoc/tag/dictionary", function() {
    //TODO
});