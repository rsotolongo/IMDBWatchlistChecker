rm -rf out
../../jsdoc -u tutorials src -d out
