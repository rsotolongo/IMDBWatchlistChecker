Duck = (function() {
        return /** @lends Duck# */ {
            /**
               Constructs a duck. 
               @constructs
               @param tog
            */
            constructor: function(tog) {
            },
            /** Say hello. */
            quack: function() {
            }
        }
})();