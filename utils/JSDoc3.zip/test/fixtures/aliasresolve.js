/**
 * @namespace
 */
var A = {};

(function(ns) {
    /**
     * @namespace
     * @alias A.F
     */
    var f = {};

    /**
     * @return {String}
     */
    f.method = function(){};

    ns.F = f;
})(A);