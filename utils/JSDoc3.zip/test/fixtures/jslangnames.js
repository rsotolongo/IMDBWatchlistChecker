
/** @namespace */
var constructor = {
    /** document me */
    toString: function(){}
};

/** @namespace */
var prototye = {
    /** document me */
    valueOf: function(){}
}

/** 
    This is Object
    @namespace Object
*/

/**
    This is Object.hasOwnProperty
    @method Object.hasOwnProperty
 */

// NOTE: you can't document a prototype of an object in JSDoc -- seriously, you just can't