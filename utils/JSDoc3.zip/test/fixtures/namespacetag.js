/** @namespace */
var x = {
};
/** @namespace Foo */
/** @namespace {function} Bar */
