/** @typedef {(string|number)} calc.NumberLike */

/** @param {calc.NumberLike} x A number or a string. */
calc.readNumber = function(x) {
}