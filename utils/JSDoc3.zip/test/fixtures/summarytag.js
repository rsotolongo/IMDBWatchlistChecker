/** @summary I do not like green eggs and ham! */
function Sam() {
}
