/**
 * @module bookshelf
 */

/**
 * @class
 */
this.Book = function(title) {
    /** document me */
    this.title = title;
}