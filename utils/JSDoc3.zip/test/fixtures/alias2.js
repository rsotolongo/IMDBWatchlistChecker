(function() {
    
    /** @alias ns.Myclass# */
    var x = {
        /** document me */
        myProperty: 'foo'
    }
    
    return x;
})();