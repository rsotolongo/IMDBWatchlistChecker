/**
 * Asdf.
 * @class
 * @classdesc A description of the class.
 */
function Foo () {
}
