/** Some documentation.
 * @tutorial tute1
 * @tutorial tute2
 */
var x;
